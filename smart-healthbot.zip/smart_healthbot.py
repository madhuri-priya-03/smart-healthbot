import streamlit as st
from textblob import TextBlob

st.set_page_config(page_title="Smart HealthBot", layout="centered")
st.title("🤖 Smart HealthBot")
st.write("Welcome! Describe how you're feeling, and I’ll try to help.")

user_input = st.text_area("How are you feeling today?", height=150)

if st.button("Analyze"):
    if user_input:
        blob = TextBlob(user_input)
        sentiment = blob.sentiment.polarity

        st.subheader("Analysis Result:")
        if sentiment > 0.2:
            st.success("You're sounding positive! Keep it up 💪")
        elif sentiment < -0.2:
            st.warning("You might be feeling down. Remember to take care of yourself ❤️")
        else:
            st.info("You're sounding neutral. Maybe some rest or a walk will help 🙂")
    else:
        st.error("Please enter some text to analyze.")