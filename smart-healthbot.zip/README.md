# Smart HealthBot 🤖

A simple AI-powered chatbot that analyzes user input to provide basic emotional and wellness feedback.

## Features
- Sentiment analysis using TextBlob
- Easy-to-use web interface with Streamlit

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run the app: `streamlit run smart_healthbot.py`